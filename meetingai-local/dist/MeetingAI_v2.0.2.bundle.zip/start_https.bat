@echo off
python meetingai.py --https
pause
