@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (py -3 MeetingAI.py --self-test) else (python MeetingAI.py --self-test)
pause
