@echo off
python meetingai.py --http --host 0.0.0.0 --port 7777
pause
