#!/usr/bin/env python3
"""Run MeetingAI's isolated built-in integration tests."""
from pathlib import Path
import subprocess
import sys

script = Path(__file__).with_name("MeetingAI.py")
raise SystemExit(subprocess.call([sys.executable, str(script), "--self-test", "--no-browser"]))
