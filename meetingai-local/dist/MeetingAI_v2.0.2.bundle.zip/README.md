# MeetingAI 1.7.0

MeetingAI 是单文件 Python 自托管实时会议 / 常驻 AI 工作台。把 `meetingai.py` 放在空目录运行，首次启动自动释放 Web UI、Prompt、Schema、安装说明等受管文件。浏览器是唯一麦克风来源，服务器不需要声卡或 `sounddevice`。

## 核心结构

- 浏览器麦克风 → 智能音频块 → HTTP POST → 浏览器内存重试队列 → 服务器接收队列 → FFmpeg → ASR。
- ASR 与“额外保存原始录音”完全独立，可只识别、识别+录音、只录音或全部关闭。
- AI 助手支持多对话线程；回答范围是会议级全局策略（仅会议 / AI知识 / 知识库 / 联网 / 全开），所有手工问答、问题雷达和建议问题统一继承；线程只保存回答深度等对话偏好。
- 语义问题雷达只负责识别“对方正在要求当前用户回答”的内容，不再自行猜知识范围；可快速 / 标准 / 深入回答，实际范围始终跟随全局策略。
- 会议时间线统一展示发言、提问、AI、分析、笔记和模式变化。
- AI会议笔记与会议模板独立，默认知识来源仅会议，可显式选择会议 + 知识库；支持 Markdown 表格/任务列表、历史查看和下载。
- 常驻助手模式用于工位/学习桌长期待命；长时间无声后开始新的语义阶段，不强行把全天内容当成一场连续会议。
- TXT / MD 本地知识库：递归目录扫描、SHA-256 变化检测、增量索引、manifest 兼容校验、原子替换；支持可调 chunk / overlap / Top-K / 相似度与来源展示。

## 启动

核心环境：

```powershell
python -m pip install -r requirements.txt
python meetingai.py
```

默认网络：

- Host: `0.0.0.0`
- HTTP: `7777`
- HTTPS: `7778`
- `server.mode = auto`
- 同目录存在 `ca.pem` + `ca.key` 时默认 HTTPS；不存在时醒目提示并回退 HTTP。

HTTP 开发：

```powershell
python meetingai.py --http
```

## FunASR

MeetingAI 不自动选择 CUDA/PyTorch 版本。**先**按你的 CPU/GPU 环境手工安装 PyTorch + torchaudio，再安装 FunASR：

```powershell
python -m pip install -U funasr modelscope
```

验证：

```powershell
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
python -c "from funasr import AutoModel; print('FunASR OK')"
```

本地 ASR 还需要 FFmpeg：

```powershell
ffmpeg -version
```

## 知识库

后台 → **知识库**：

1. 新建知识库。
2. 保存 `.txt` / `.md` 原文。
3. 重建索引。
4. 在 AI 助手里选择“知识库”或“全开”，单选/多选知识库。

知识原文在 `data/knowledge/<kb>/source/`，索引在 `data/knowledge/<kb>/index/`。索引是缓存，可以随时重建。知识片段会作为不可信参考数据注入模型，不能覆盖 System Prompt。

## 会议模板与运行中调整

内置模板：通用会议、日常早会、快速应答、助理记录、老板会议、常驻助手。系统模板可复制；个人模板可新增/修改/删除/设默认。

运行中点击会议标题下方的模板按钮即可热切换或单项覆盖：工作模式、布局、默认回答深度、知识库、问题雷达、自动回答、扫描速度、会议分析、ASR、录音存档等。全局回答范围独立于模板，避免切模板时悄悄改变知识来源。切换不会重启会议，也不会清空历史。

## 版本与 Schema

根目录会生成：

- `VERSION.json`
- `schemas/config.schema.json`
- `schemas/meeting.schema.json`
- `schemas/preset.schema.json`
- `schemas/chat.schema.json`
- `schemas/knowledge.schema.json`
- `schemas/notes.schema.json`
- `schemas/update.schema.json`

1.7.0 使用新的 Schema 8 数据模型。本版按干净新配置设计，不兼容旧版配置/会议数据；遇到旧 Schema 会明确拒绝，而不是静默迁移或猜测。

## 自动更新

后台 → **版本与更新** 可配置 manifest URL。Manifest 示例：

```json
{
  "product": "MeetingAI",
  "version": "1.5.1",
  "channel": "stable",
  "url": "https://example.com/meetingai.py",
  "sha256": "64位十六进制SHA256"
}
```

下载前后执行：URL/manifest 校验 → 最大 32 MiB → SHA-256 → Python compile → 写入 updates → 备份当前主程序 → 原子替换。应用后需要手工重启。默认不配置更新地址，也不会自行从任意互联网来源更新。

## 弱网与异步

- 音频使用独立 `AudioUploadQueue`，按 `session + seq` 幂等上传。
- 手工记录、逐字稿标记、人工会议笔记使用独立轻量 `OperationQueue`，UI先响应，网络恢复后按序补交。
- 顶部延迟使用最近 3 秒成功样本平均、每 1 秒刷新；健康状态使用 15 秒窗口，单次失败忽略，默认连续 3 次判波动、5 次判异常。
- 默认延迟分级：0–3s 良好；3–5s 正常；5–10s 提醒；≥10s 异常，全部可在高级 JSON 中热加载。
- 麦克风使用浏览器 `GainNode` 真正放大输入，默认 1.0×、可调 0.25×–4.0×；dBFS 显示增强后的实际送 ASR 电平。服务器另提供可选 ASR 预处理增益。

## 安全边界

- 多个共享密码，权限相同，可独立禁用/删除并设置登录提示。
- 密码 PBKDF2 哈希，HMAC Session Cookie，写请求 CSRF/Origin 检查。
- API Key 不下发浏览器。
- Forwarded Header 只信任配置 CIDR；PROXY Protocol v2 为独立高级入口，同样受可信 CIDR 约束。
- Markdown 先转义 HTML，再渲染受限 Markdown；不会把模型返回的 `<script>` 或事件属性直接当 HTML 执行。

## 自检

```powershell
python meetingai.py --self-test
```

完整测试脚本：

```powershell
python test_meetingai.py
```


## 深度思考

回答深度与知识范围完全独立：快速 / 标准 / 深入只控制推理方式。深入模式会通过 Provider 能力层尽可能启用真实 reasoning / think；支持 Ollama `think`，OpenAI-compatible Provider 可配置 reasoning 参数。若模型不支持原生推理，系统会退化为深入分析 Prompt，并在任务元数据中明确记录 fallback，不伪装为已开启 Think。

## Origin 与地址

前端所有 API 使用当前页面 origin / 相对路径，不配置 Public Base URL。域名、局域网 IP、localhost 和可信反向代理都沿用浏览器当前访问地址。只有在 `forwarded` 模式且 TCP 对端命中可信代理 CIDR 时，后端才采纳 `X-Forwarded-Proto` / `X-Forwarded-Host`。`/api/status` 会返回当前请求看到的 Origin、Host、客户端 IP 和代理判定用于诊断。


## v1.8 runtime notes

- ASR can warm up after server start so the first meeting audio does not pay model/VAD cold-start cost.
- FunASR online update checks and ModelScope network policy are configurable.
- Topic history and topic-switch stickiness keep Meeting Intelligence readable while live brief remains fast.
- Ending a meeting guarantees a final AI note when the note is missing or stale.
- v1.8 establishes migration metadata for future compatibility upgrades; v1.8 itself intentionally uses a clean schema.


## v1.9.1
Focus mode hotfix: on desktop, expanding transcript/intelligence/assistant now overrides custom three-column ratios and occupies the full workspace. Schema remains 11.


## v1.9.2
- Restores the desktop meeting workspace to the stable horizontal three-column layout.
- Supports collapsing at most one pane into a narrow rail; the other two expand horizontally.
- Focus mode shows one pane at 100% and restores the previous collapsed state when exited.
- Meeting Intelligence key-items UI is unchanged.
- v1.9.2 uses schema 12; schema 11 from v1.9.1 migrates automatically with backup.


## v1.9.2 Workspace hotfix
- Desktop workspace defaults to a horizontal three-column layout.
- At most one pane can collapse to a narrow rail; the other two expand horizontally.
- Focus mode shows one pane at 100% and restores the pre-focus collapsed state.
- Meeting Intelligence key-items UI is unchanged.
- Schema 10/11 migrate to schema 12 with backups.


## v1.9.3 Workspace collapse hotfix

- Fixes collapse buttons toggling twice because the click bubbled into the collapsed-rail handler.
- Collapse/restore now updates immediately before server persistence.
- Workspace preference writes are serialized so rapid clicks cannot leave stale server state.
- Schema remains 12; v1.9.2 data/config are directly compatible.


## v2.0 新增
- 会议高级功能支持超长音频导入（FFmpeg 分段 + 后台 ASR）。
- 运行环境页检测 CPU/GPU/CUDA/FFmpeg/依赖，并可安装或修复 Python 运行依赖；不会安装 Python 本体。
- 支持中国大陆 Pip 镜像、HF 镜像和按作用域代理。


## v2.0.1 ASR 语义标注
原始 transcript.jsonl 永远保留 ASR/人工原文；AI 标注写入独立 transcript_semantics.jsonl。可在“语音与录音”中设置保守/均衡/积极强度、自动采用阈值、关键事实阈值、批量大小与上下文窗口。AI 标注失败时所有会议功能自动回退原文。


## v2.0.2 ASR 语义标注可视化
- 会议页增加“语义校验”状态信号、AI辅助/原始逐字稿切换和待确认入口。
- corrected / uncertain / critical_uncertain 采用轻量徽标，点击可查看原始识别、AI建议、置信度和理由。
- 增加待确认中心、历史会议重新语义校验、音频导入任务语义状态提示。
- “语音与录音”中将语义校验整理为独立卡片；高级阈值继续保留。
- 原始 transcript.jsonl 仍为不可变证据；Schema 保持 14，本次无需数据迁移。
