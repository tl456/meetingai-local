@echo off
python meetingai.py
pause
