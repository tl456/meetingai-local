# MeetingAI migrations

v1.9.0 activates migration framework v1. Supported source: v1.8.x schema 10. Target: schema 11. Config and meeting state are backed up before mutation. Transcript/notes/chat/event JSONL files are not rewritten.


v1.9.1 is a schema-preserving UI hotfix. Upgrading from v1.9.0 requires no data migration.


v1.9.2 is a schema-preserving workspace layout hotfix. Upgrading from v1.9.1 requires no data migration.

## v1.9.3

UI hotfix only. Schema remains 12; no migration is required from v1.9.2.
