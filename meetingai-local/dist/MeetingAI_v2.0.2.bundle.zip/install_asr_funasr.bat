@echo off
chcp 65001 >nul
echo 请先安装与你 CPU/CUDA 环境匹配的 PyTorch + torchaudio。
echo 验证: python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
pause
python -m pip install -U funasr modelscope
pause
