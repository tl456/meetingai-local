@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo MeetingAI 基础依赖将由你手工触发安装。
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -m pip install -r requirements.txt
) else (
  python -m pip install -r requirements.txt
)
pause
