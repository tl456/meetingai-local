@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (py -3 MeetingAI.py --reset-password) else (python MeetingAI.py --reset-password)
pause
